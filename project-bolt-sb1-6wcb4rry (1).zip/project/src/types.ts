export interface User {
  id: string;
  email: string;
  role: 'user' | 'management';
  full_name: string;
  phone: string;
}

export interface LostPerson {
  id: string;
  name: string;
  photo_url: string;
  guardian_phone: string;
  last_seen_location: string;
  reported_at: string;
  status: 'active' | 'found';
  description: string;
}

export interface CrowdReport {
  id: string;
  location: string;
  video_url: string;
  status: 'pending' | 'processed';
  crowd_level: 'low' | 'medium' | 'high' | 'critical';
  reported_by: string;
  reported_at: string;
}

export interface TeamMessage {
  id: string;
  sender_id: string;
  content: string;
  sent_at: string;
  attachments?: string[];
}