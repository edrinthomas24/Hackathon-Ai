import React, { useState } from 'react';
import { Upload, AlertTriangle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';

export default function ReportCrowd() {
  const { user } = useAuth();
  const [location, setLocation] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [uploading, setUploading] = useState(false);

  async function handleVideoUpload(event: React.ChangeEvent<HTMLInputElement>) {
    try {
      setUploading(true);
      if (!event.target.files || event.target.files.length === 0) {
        throw new Error('You must select a video to upload.');
      }

      const file = event.target.files[0];
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random()}.${fileExt}`;
      const filePath = `${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('crowd-videos')
        .upload(filePath, file);

      if (uploadError) {
        throw uploadError;
      }

      const { data } = supabase.storage.from('crowd-videos').getPublicUrl(filePath);

      setVideoUrl(data.publicUrl);
      toast.success('Video uploaded successfully');
    } catch (error) {
      toast.error('Error uploading video');
      console.error('Error:', error);
    } finally {
      setUploading(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;

    try {
      const { error } = await supabase.from('crowd_reports').insert([
        {
          location,
          video_url: videoUrl,
          reported_by: user.id,
          status: 'pending',
        },
      ]);

      if (error) throw error;

      toast.success('Report submitted successfully');
      setLocation('');
      setVideoUrl('');
    } catch (error) {
      console.error('Error:', error);
      toast.error('Failed to submit report');
    }
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
        <div className="flex">
          <div className="flex-shrink-0">
            <AlertTriangle className="h-5 w-5 text-yellow-400" />
          </div>
          <div className="ml-3">
            <p className="text-sm text-yellow-700">
              Please only submit reports for genuine crowd safety concerns. False reports may
              result in account suspension.
            </p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold mb-6">Report Crowd Situation</h2>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700">Location</label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="Enter the location details"
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Upload Video Evidence
            </label>
            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
              <div className="space-y-1 text-center">
                <Upload className="mx-auto h-12 w-12 text-gray-400" />
                <div className="flex text-sm text-gray-600">
                  <label
                    htmlFor="video-upload"
                    className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500"
                  >
                    <span>Upload a video</span>
                    <input
                      id="video-upload"
                      name="video-upload"
                      type="file"
                      accept="video/*"
                      className="sr-only"
                      onChange={handleVideoUpload}
                      required={!videoUrl}
                    />
                  </label>
                  <p className="pl-1">or drag and drop</p>
                </div>
                <p className="text-xs text-gray-500">MP4, WebM up to 100MB</p>
              </div>
            </div>
          </div>

          {videoUrl && (
            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Video Preview
              </label>
              <video
                src={videoUrl}
                controls
                className="w-full rounded-lg"
                style={{ maxHeight: '300px' }}
              >
                Your browser does not support the video tag.
              </video>
            </div>
          )}

          <button
            type="submit"
            disabled={!location || !videoUrl || uploading}
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
          >
            {uploading ? 'Uploading...' : 'Submit Report'}
          </button>
        </form>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-medium mb-4">Guidelines for Reporting</h3>
        <ul className="space-y-2 text-gray-600">
          <li className="flex items-start">
            <span className="h-6 w-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mr-2">
              1
            </span>
            Capture clear video evidence of the crowd situation
          </li>
          <li className="flex items-start">
            <span className="h-6 w-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mr-2">
              2
            </span>
            Provide accurate location details
          </li>
          <li className="flex items-start">
            <span className="h-6 w-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mr-2">
              3
            </span>
            Report only genuine safety concerns
          </li>
          <li className="flex items-start">
            <span className="h-6 w-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mr-2">
              4
            </span>
            Ensure the video is recent (within the last hour)
          </li>
        </ul>
      </div>
    </div>
  );
}