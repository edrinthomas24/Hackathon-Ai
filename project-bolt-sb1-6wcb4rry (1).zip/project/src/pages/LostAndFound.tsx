import React, { useState, useEffect } from 'react';
import { Upload, Search, AlertCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { LostPerson } from '../types';
import { format } from 'date-fns';
import toast from 'react-hot-toast';

export default function LostAndFound() {
  const [reports, setReports] = useState<LostPerson[]>([]);
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState('');
  const [guardianPhone, setGuardianPhone] = useState('');
  const [lastSeenLocation, setLastSeenLocation] = useState('');
  const [description, setDescription] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    fetchReports();
  }, []);

  async function fetchReports() {
    try {
      const { data, error } = await supabase
        .from('lost_persons')
        .select('*')
        .order('reported_at', { ascending: false });

      if (error) throw error;
      setReports(data || []);
    } catch (error) {
      console.error('Error fetching reports:', error);
      toast.error('Failed to load reports');
    } finally {
      setLoading(false);
    }
  }

  async function handlePhotoUpload(event: React.ChangeEvent<HTMLInputElement>) {
    try {
      setUploading(true);
      if (!event.target.files || event.target.files.length === 0) {
        throw new Error('You must select an image to upload.');
      }

      const file = event.target.files[0];
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random()}.${fileExt}`;
      const filePath = `${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('lost-person-photos')
        .upload(filePath, file);

      if (uploadError) {
        throw uploadError;
      }

      const { data } = supabase.storage
        .from('lost-person-photos')
        .getPublicUrl(filePath);

      setPhotoUrl(data.publicUrl);
      toast.success('Photo uploaded successfully');
    } catch (error) {
      toast.error('Error uploading photo');
      console.error('Error:', error);
    } finally {
      setUploading(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    try {
      const { error } = await supabase.from('lost_persons').insert([
        {
          name,
          photo_url: photoUrl,
          guardian_phone: guardianPhone,
          last_seen_location: lastSeenLocation,
          description,
          status: 'active',
        },
      ]);

      if (error) throw error;

      toast.success('Report submitted successfully');
      setName('');
      setGuardianPhone('');
      setLastSeenLocation('');
      setDescription('');
      setPhotoUrl('');
      fetchReports();
    } catch (error) {
      console.error('Error:', error);
      toast.error('Failed to submit report');
    }
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold mb-4">Report Missing Person</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Guardian Phone
              </label>
              <input
                type="tel"
                value={guardianPhone}
                onChange={(e) => setGuardianPhone(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                required
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Last Seen Location
            </label>
            <input
              type="text"
              value={lastSeenLocation}
              onChange={(e) => setLastSeenLocation(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Photo</label>
            <div className="mt-1 flex items-center">
              <input
                type="file"
                accept="image/*"
                onChange={handlePhotoUpload}
                className="sr-only"
                id="photo-upload"
              />
              <label
                htmlFor="photo-upload"
                className="cursor-pointer bg-white py-2 px-3 border border-gray-300 rounded-md shadow-sm text-sm leading-4 font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                {uploading ? 'Uploading...' : 'Upload Photo'}
              </label>
              {photoUrl && (
                <img
                  src={photoUrl}
                  alt="Preview"
                  className="ml-4 h-16 w-16 object-cover rounded-md"
                />
              )}
            </div>
          </div>
          <button
            type="submit"
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            Submit Report
          </button>
        </form>
      </div>

      <div className="bg-white rounded-lg shadow-md">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold">Active Reports</h2>
        </div>
        <div className="divide-y divide-gray-200">
          {loading ? (
            <div className="p-6 text-center text-gray-500">Loading reports...</div>
          ) : reports.length === 0 ? (
            <div className="p-6 text-center text-gray-500">No active reports</div>
          ) : (
            reports.map((report) => (
              <div key={report.id} className="p-6 hover:bg-gray-50">
                <div className="flex items-start space-x-4">
                  {report.photo_url && (
                    <img
                      src={report.photo_url}
                      alt={report.name}
                      className="h-24 w-24 object-cover rounded-lg"
                    />
                  )}
                  <div className="flex-1">
                    <h3 className="text-lg font-medium">{report.name}</h3>
                    <p className="text-sm text-gray-500">
                      Last seen: {report.last_seen_location}
                    </p>
                    <p className="text-sm text-gray-500">
                      Reported: {format(new Date(report.reported_at), 'PPp')}
                    </p>
                    <p className="mt-2">{report.description}</p>
                    <div className="mt-2">
                      <a
                        href={`tel:${report.guardian_phone}`}
                        className="inline-flex items-center text-sm text-blue-600 hover:text-blue-500"
                      >
                        <AlertCircle className="h-4 w-4 mr-1" />
                        Contact Guardian: {report.guardian_phone}
                      </a>
                    </div>
                  </div>
                  <span
                    className={`px-2 py-1 rounded-full text-sm font-medium ${
                      report.status === 'active'
                        ? 'bg-red-100 text-red-800'
                        : 'bg-green-100 text-green-800'
                    }`}
                  >
                    {report.status.charAt(0).toUpperCase() + report.status.slice(1)}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}