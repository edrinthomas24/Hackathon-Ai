import React, { useEffect, useState } from 'react';
import { AlertTriangle, Users, MapPin } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { CrowdReport } from '../types';
import { format } from 'date-fns';

export default function Dashboard() {
  const [crowdReports, setCrowdReports] = useState<CrowdReport[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCrowdReports();
  }, []);

  async function fetchCrowdReports() {
    try {
      const { data, error } = await supabase
        .from('crowd_reports')
        .select('*')
        .order('reported_at', { ascending: false })
        .limit(10);

      if (error) throw error;
      setCrowdReports(data || []);
    } catch (error) {
      console.error('Error fetching crowd reports:', error);
    } finally {
      setLoading(false);
    }
  }

  function getCrowdLevelColor(level: string) {
    switch (level) {
      case 'critical':
        return 'bg-red-100 text-red-800';
      case 'high':
        return 'bg-orange-100 text-orange-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'low':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  }

  return (
    <div className="space-y-6">
      <div className="bg-blue-600 text-white rounded-lg p-6">
        <h1 className="text-2xl font-bold mb-2">Crowd Management Dashboard</h1>
        <p className="text-blue-100">Real-time crowd monitoring and incident management</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Active Alerts</h2>
            <AlertTriangle className="h-8 w-8 text-red-500" />
          </div>
          <p className="text-3xl font-bold mt-2">
            {crowdReports.filter(r => r.crowd_level === 'critical').length}
          </p>
          <p className="text-gray-500">Critical crowd situations</p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Monitored Zones</h2>
            <MapPin className="h-8 w-8 text-blue-500" />
          </div>
          <p className="text-3xl font-bold mt-2">{crowdReports.length}</p>
          <p className="text-gray-500">Active monitoring areas</p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Total Reports</h2>
            <Users className="h-8 w-8 text-green-500" />
          </div>
          <p className="text-3xl font-bold mt-2">{crowdReports.length}</p>
          <p className="text-gray-500">Crowd reports today</p>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold">Recent Crowd Reports</h2>
        </div>
        <div className="divide-y divide-gray-200">
          {loading ? (
            <div className="p-6 text-center text-gray-500">Loading reports...</div>
          ) : crowdReports.length === 0 ? (
            <div className="p-6 text-center text-gray-500">No reports available</div>
          ) : (
            crowdReports.map((report) => (
              <div key={report.id} className="p-6 hover:bg-gray-50">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-medium">{report.location}</h3>
                    <p className="text-sm text-gray-500">
                      Reported at {format(new Date(report.reported_at), 'PPp')}
                    </p>
                  </div>
                  <span
                    className={`px-3 py-1 rounded-full text-sm font-medium ${getCrowdLevelColor(
                      report.crowd_level
                    )}`}
                  >
                    {report.crowd_level.charAt(0).toUpperCase() + report.crowd_level.slice(1)}
                  </span>
                </div>
                {report.video_url && (
                  <div className="mt-4">
                    <video
                      src={report.video_url}
                      controls
                      className="w-full rounded-lg"
                      style={{ maxHeight: '200px' }}
                    >
                      Your browser does not support the video tag.
                    </video>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}